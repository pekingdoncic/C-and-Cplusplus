#include<iostream>

using namespace std;
int dfs(int n)
{
	if (n == 0)					// 递归终止条件
		return 0;
	else
		return dfs(n / 2);     
}

int main()
{
	int n;
	while (cin >> n)
		cout << dfs(n) + 1 << endl;

	return 0;
}