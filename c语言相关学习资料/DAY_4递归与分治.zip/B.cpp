#include <iostream>

using namespace std;
typedef long long LL;

/*
如果r为奇数，f(r, k) = f((r+1)/2, k-1) * 2
如果r为偶数，f(r, k) = f(r/2, k-1)
*/
LL f(LL r, LL k)        // k个小时后第r行红气球的个数
{ 
    if(k == 0)          // 第r行和第r - 1行有关
        return 1LL;

    if(r % 2 != 0) return f((r+1)/2 ,k-1) * 2;
    else return f(r/2, k-1);
}
 

/*
如果r为偶数，g(r, k) = g(r/2, k-1) * 3;
如果r为奇数，g(r, k) = g(r-1, k) + f(r, k);
*/
LL g(LL r, LL k)        // k个小时后前r行红气球的个数。
{
    if(r == 0) 
        return 0;

    if(k == 0) 
        return 1LL;

    LL ans = g(r/2, k-1) * 3;
    if(r % 2 != 0) ans += f(r, k);
    return ans;
}

int main()
{
    int T;
    cin >> T;
    for(int kase = 1; kase <= T; kase++)
    {
        LL k, a, b;
        cin >> k >> a >> b;
        printf("Case %d: %lld\n", kase, g(b, k) - g(a-1, k));
    }

    return 0;
}