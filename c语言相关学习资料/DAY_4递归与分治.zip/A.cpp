#include <iostream>
#include <algorithm>
#define ll long long

using namespace std;
const int N = 100010;

struct point
{
    double x, y;
}pt[N];

int a[N], n;

bool cmp(point a, point b)
{
    if (a.x != b.x) return a.x < b.x;
    else return a.y < b.y;
}
bool cmp_y(int id1, int id2) {
    return pt[id1].y < pt[id2].y;
}
double getdis(const point& a, const point& b)
{                                  //两点间距离公式
    double x = a.x - b.x;
    double y = a.y - b.y;
    return sqrt(x * x + y * y);
}
double solve(int l, int r)
{
    double ans = 0;
    if (r - l <= 2)
    {
        if (r - l == 0)             // 中间没有数
            return ans;

        ans = getdis(pt[l], pt[l + 1]);

        if (r - l == 1)             // 中间一个数
            return ans; 

        for (int i = l; i < r; ++i) // 中间两个数
        {
            for (int j = i + 1; j <= r; ++j)
            {
                ans = min(ans, getdis(pt[i], pt[j]));
            }                       // ans 和 i，j两点距离的min
        }
        return ans;
    }
        
    int m = (l + r) >> 1;       // 先来看这里，第一步，分解为子问题
    double s1 = solve(l, m);    // 第二步，递归处理子问题
    double s2 = solve(m + 1, r);

    // 第三步：合并子问题
    ans = min(s1, s2);          
    int k = 0;
    for (int i = m - 1; i >= l && pt[m].x - pt[i].x <= ans; --i) a[k++] = i;
    for (int i = m + 1; i <= r && pt[i].x - pt[m].x <= ans; ++i) a[k++] = i;
                               
    sort(a, a + k, cmp_y);      // 根据y进行排序

    for (int i = 0; i < k; ++i)
    {
        for (int j = i + 1; j < k; j++)
        {
            if (pt[a[j]].y - pt[a[i]].y >= ans)
                break;          // 取ans
            ans = min(ans, getdis(pt[a[i]], pt[a[j]]));
        }

    }
    return ans;
}
int main()
{
    while (cin >> n)
    {
        if (!n) break;

        for (int i = 0; i < n; ++i)
            cin >> pt[i].x >> pt[i].y;

        sort(pt, pt + n, cmp);              // 根据x进行排序

        printf("%.2lf\n", solve(0, n - 1) / 2.0);
    }
    return 0;
}
