#include <iostream>
#include <algorithm>
#define ll long long
using namespace std;

const int MAXN = 5e5 + 7;
int arr[MAXN], n;
ll ans;

void mergeSort(int l, int r)
{
    if (l == r)             // 递归终止条件,只有一个数的区间
        return;

    int m = (l + r) / 2;    // 分解为子问题
    mergeSort(l, m);        // 递归处理子问题
    mergeSort(m + 1, r);

    int* a = new int[r - l + 1];
    int i = l, j = m + 1, k = 0;
    while (i <= m && j <= r)
    {
        if (arr[i] < arr[j]) // 不满足逆序对
            a[k++] = arr[i++];
        else
        {
            a[k++] = arr[j++];
            ans += m - i + 1; //逆序对 
        }
    }
    while (i <= m)
        a[k++] = arr[i++];
    while (j <= r)
        a[k++] = arr[j++];

    for (int i = 0; i <= r - l; i++)
        arr[l + i] = a[i];
    delete[] a;
}

int main()
{
    while (cin >> n)
    {
        if (n == 0)
            break;

        ans = 0;
        for (int i = 0; i < n; i++)
            cin >> arr[i];

        mergeSort(0, n - 1);

        cout << ans << endl;
    }
    return 0;
}
